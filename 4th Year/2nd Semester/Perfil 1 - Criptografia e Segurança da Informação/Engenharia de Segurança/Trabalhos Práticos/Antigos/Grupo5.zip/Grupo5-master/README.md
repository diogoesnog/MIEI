# Grupo5

Elementos:
- Daniel Maia (a77531)
- Diogo Costa (a78034)
- Mafalda Nunes (a77364)
