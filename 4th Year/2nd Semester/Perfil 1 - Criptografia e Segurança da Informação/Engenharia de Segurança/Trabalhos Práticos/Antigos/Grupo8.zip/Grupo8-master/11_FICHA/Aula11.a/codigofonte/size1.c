/* Exemplo retirado de http://www.geeksforgeeks.org/memory-layout-of-c-program/ */
#include <stdio.h>
 
int main(void)
{
    return 0;
}
