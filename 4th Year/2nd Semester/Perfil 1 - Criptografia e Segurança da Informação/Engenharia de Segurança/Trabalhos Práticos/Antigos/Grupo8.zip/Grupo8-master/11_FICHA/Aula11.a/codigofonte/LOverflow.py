importantData = 1
buffer=[None]*10
for i in range(0,500):
	print "i =", i
	buffer[i]=7
print "after buffer overfow"
importantData

