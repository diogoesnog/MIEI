# Grupo7

1. Resolução do Guião 1 Correspondente à Aula 2 (11/02/2019) em <a href=https://github.com/uminho-miei-engseg-18-19/Grupo7/tree/master/Aula2>Aula 2</a>

2. Resolução do Guião 2 Correspondente à Aula 3 (18/02/2019) em <a href=https://github.com/uminho-miei-engseg-18-19/Grupo7/tree/master/Aula3>Aula 3</a>

3. Resolução do Guião 3 Correspondente à Aula 4 (25/02/2019) em <a href=https://github.com/uminho-miei-engseg-18-19/Grupo7/tree/master/Aula4>Aula 4</a>

4. Resolução do Guião 4 Correspondente à Aula 7 (18/02/2019) em <a href=https://github.com/uminho-miei-engseg-18-19/Grupo7/tree/master/Aula5>Aula 5</a>

5. Resolução do Guião 5 Correspondente à Aula 8 (25/03/2019) em <a href=https://github.com/uminho-miei-engseg-18-19/Grupo7/tree/master/Aula8>Aula 8</a>

6. Resolução do Guião 6 Correspondente à Aula 9 (01/04/2019) em <a href=https://github.com/uminho-miei-engseg-18-19/Grupo7/tree/master/Aula9>Aula 9</a>

7. Resolução do Guião 7 Correspondente à Aula 10 (08/04/2019) em <a href=https://github.com/uminho-miei-engseg-18-19/Grupo7/tree/master/Aula10>Aula 10</a>

8. Resolução do Guião 8 Correspondente à Aula 11 (29/04/2019) em <a href=https://github.com/uminho-miei-engseg-18-19/Grupo7/tree/master/Aula11>Aula 11</a>
