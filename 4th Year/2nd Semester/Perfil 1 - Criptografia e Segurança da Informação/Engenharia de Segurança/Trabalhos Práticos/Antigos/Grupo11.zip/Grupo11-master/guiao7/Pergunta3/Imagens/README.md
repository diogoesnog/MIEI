Imagens referentes à pergunta 3 do guião 10.
