Resolução do guião 3
