## Resolução da pergunta 1

# Perguntas do guiao anterior!!!!!

O Ficheiro Perguntas 1.1, 1.2 e 1.4 é referente ao trabalho prático 8 e não ao trabalho prático 9
