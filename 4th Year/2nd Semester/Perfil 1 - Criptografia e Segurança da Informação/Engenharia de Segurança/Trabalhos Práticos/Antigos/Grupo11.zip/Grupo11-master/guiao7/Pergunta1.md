## Pergunta 1

Como vimos na aula anterior a fórmula do risco é a seguinte:
*risk = probability of attack to succeed * impact*

onde 
*probability of attack to succeed = level of threat * degree of vulnerability*

### Pergunta 1.1

Nesta pergunta opomos o risco inerente a ter um computador pessoal conectado à rede versus o risco de ter um servidor de homebanking. Olhando para a formula do risco podemos ver que no caso do computador pessoal tem uma maior problabilidade de o ataque ser bem sucedido, visto que normalmente um computador normal não inspira medidas reforçadas de segurança, porque caso seja comprometido o impacto desta falha costuma ser de pequeno a moderado. Concluimos então que para o primeiro caso, o primeiro fator é elevado (probability of attack to succeed) e o segundo (impact) é baixo. No caso do homebanking  é notório que o impacto de um ataque é muito grande e pode ter consequencias catastróficas para o banco. No caso da probabilidade de do ataque ser bem sucecido, podemos afirmar que o nivel de ameaça é muito alto, e o grau de vulnerabilidade em principio é baixo, visto que estes servidores normalmente são sujeitos a normais de segurança muito rigidas.
Em suma, ponderando os pesos de cada variável, podemos afirmar que um servidor de homebanking apresenta um risco superior ao computador pessoal.

