Imagens referentes à pergunta 3 
