### Pergunta 2.1
Tal como o modelo de cascata, no modelo Microsoft Security Development Lifecycle é necessário ter em conta o regulamento europeu RGPD na Fase de Requisitos, mais especificamente, nos requisitos relativos à segurança.

### Pergunta 2.3
Relativamente aos projectos de desenvolvimento de software que já realizamos, podemos dizer que as funções especificadas na secção 2.3 do Key Roles and Responsibilities in the SDLC são mais bem definidas que as funções atribuidas nos nossos projectos, sendo que a maior parte não era atribuida a nenhum membro.
Visto que nem todos os cargos eram preenchidos nos nossos projectos de desenvolvimento de software algumas responsabilidades também não conseguem ser atribuidas e, por consequência, não conseguimos chegar aos padrões estabelecidos no Key Roles and Responsibilities in the SDLC.
