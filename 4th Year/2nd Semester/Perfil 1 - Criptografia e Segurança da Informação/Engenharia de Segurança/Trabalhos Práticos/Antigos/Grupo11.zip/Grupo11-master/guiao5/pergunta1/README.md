## Resolução da pergunta 1

A ppergunta um tinha como objetivo perceber o funcionamento de uma blockchain implementada em *javascript*.

### Pergunta 1.1
Nesta pergunta tivemos de alterar o medodo *createGenesisBlock()* de maneira a incluir a informação indicada no enunciado (timestamp e dados)

### Pergunta 1.2

Esta tinha como objetivo simular o encadeamento de diversos blocos na blockchain, com cada bloco contendo diversas transações.
Como neste caso as estruturas eram muito simples, decidimos em cada bloco, colocar um array de objetos, sendo que cada objeto representava uma *transação* 


