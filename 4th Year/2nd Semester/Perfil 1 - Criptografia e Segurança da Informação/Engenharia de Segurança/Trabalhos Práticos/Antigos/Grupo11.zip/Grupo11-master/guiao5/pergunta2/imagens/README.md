Imagens referentes à pergunta 2.1
