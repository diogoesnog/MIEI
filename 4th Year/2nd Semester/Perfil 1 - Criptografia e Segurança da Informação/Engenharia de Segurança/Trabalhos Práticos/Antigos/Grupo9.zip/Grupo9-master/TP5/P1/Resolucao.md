# TP5 - Resolução 

### Pergunta 1.1

Foi necessário alterar o código no método createGenesisBlock() de forma a incluir timestamp do dia de hoje e os dados ("Bloco inicial da koreCoin"

### Pergunta 1.2

Nesta pergunta, adicionamos alguns blocos com diferentes quantidades que simulam várias transações em cada um deles.
