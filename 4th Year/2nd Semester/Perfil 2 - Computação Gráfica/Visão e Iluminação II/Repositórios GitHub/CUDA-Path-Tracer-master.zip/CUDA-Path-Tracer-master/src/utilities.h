#pragma once

#include "glm/glm.hpp"
#include <algorithm>
#include <istream>
#include <ostream>
#include <iterator>
#include <sstream>
#include <string>
#include <vector>

#define ERRORCHECK 1

#define PI                3.1415926535897932384626422832795028841971f
#define TWO_PI            6.2831853071795864769252867665590057683943f
#define SQRT_OF_ONE_THIRD 0.5773502691896257645091487805019574556476f
#define EPSILON           0.00001f

#define STREAM_COMPACTION 1
#define CACHE_FIRST 1
#define SORT_MATERIAL 1

#define TIMER 1

#define ANTI_ALIAS 1

#define MOTION_BLUR 0
#define LOOP_TIME 250.f
#define OFFSET_AMOUNT 0.1f

#define DEPTH_OF_FIELD 0
#define BONNE_PROJECTION 0
#define LENS_RADIUS 0.2
#define FOCAL_DISTANCE 5

namespace utilityCore {
    extern float clamp(float f, float min, float max);
    extern bool replaceString(std::string& str, const std::string& from, const std::string& to);
    extern glm::vec3 clampRGB(glm::vec3 color);
    extern bool epsilonCheck(float a, float b);
    extern std::vector<std::string> tokenizeString(std::string str);
    extern glm::mat4 buildTransformationMatrix(glm::vec3 translation, glm::vec3 rotation, glm::vec3 scale);
    extern std::string convertIntToString(int number);
    extern std::istream& safeGetline(std::istream& is, std::string& t); //Thanks to http://stackoverflow.com/a/6089413
}
