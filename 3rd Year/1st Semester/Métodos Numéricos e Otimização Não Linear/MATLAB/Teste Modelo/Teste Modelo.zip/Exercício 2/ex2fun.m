function [F] = ex2fun(x)
F=((1-(1+x)^-12)/x)-((315-91)/24);
end

