format long;
x0=0.04;
options=optimset('TolX',1e-1);
[xsol,fsol,exitflag,output]=fsolve('ex2fun',x0,options)
