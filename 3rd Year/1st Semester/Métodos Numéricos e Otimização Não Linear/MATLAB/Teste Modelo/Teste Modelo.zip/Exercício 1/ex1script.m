format long; % Para dar 10 casas decimais. Caso contr�rio, apenas 4.
x0=[0 0.1];
options=optimset('TolX',1e-2,'TolFun',1e-1);
[xsol,fsol,exitflag,output]=fsolve('ex1fun',x0,options)