function [F] = ex5fun(x)
F=x.*(1-exp(-x))+x.^3;
end

