function f = ex3fun(c,x)
f=c(1)*cos(x)+c(2)+(1./x)+c(3)*x;
end

