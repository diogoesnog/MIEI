% Polin�mio Interpolador de Newton %
x1=[2 2.2 3];
y1=[3.3 3 2];

p1=polyfit(x1,y1,2) % Al�nea (b)
y11=polyval(p,2.8) % Al�nea (a)

% Splines %
x2=[1.5 2 2.2 3 3.8 4];
y2=[4.9 3.3 3 2 1.75 1.5];

xx=spline(x2,[-2 y2 3],2.5) % Al�nea (c)

pp=spline(x2,[-2 y2 3]);
pp.coefs % Al�nea (d) 

[P1,s1]=polyfit(x2,y2,1) % Al�nea (f)
y12=polyval(P1,3.5) % Al�nea (e)

[P2,s2]=polyfit(x2,y2,1) % Al�nea (h)
y13=polyval(P2,3.3) % Al�nea (g)

% Al�nea (i) � ver pelo quadrado dos NORMR.

[C,RESNORM,RESIDUAL,EXITFLAG,OUTPUT]=lsqcurvefit('ex3fun',[1 1 1],x2,y2) % Al�nea (j)
% Al�nea (k) Ver pelo res�duo.


