//
//  plano.h
//  CG-FORMAS-PRIMARIAS
//
//  Created by Hélder José Alves Gonçalves on 28/02/14.
//  Copyright (c) 2014 Hélder José Alves Gonçalves. All rights reserved.
//

#ifndef CG_FORMAS_PRIMARIAS_plano_h
#define CG_FORMAS_PRIMARIAS_plano_h

#include <iostream>
#include <math.h>

void plano(float altura, float lado, int camadas, int fatias, float z_index, int ori, FILE* f, int flag);
void planoVBO(float altura, float lado, int camadas, int fatias, float z_index, int ori, FILE *f);

#endif