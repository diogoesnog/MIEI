
// ORLA - lista com os vértices ordenados pelos pesos (decrescente)

typedef struct no {
  int vertice;
  int cost;
} No;
  
typedef struct fringe {
  int num;
  No *val;
  int tam;
} *Fringe;


Fringe newFringe (int N);
Fringe addV (Fringe f,int v, int c);
Fringe nextF (Fringe f,int *v);
Fringe updateV (Fringe f,int v, int c);



