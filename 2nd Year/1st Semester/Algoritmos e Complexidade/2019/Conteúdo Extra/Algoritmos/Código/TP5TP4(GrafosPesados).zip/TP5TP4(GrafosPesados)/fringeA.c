
// Orla - um vector com os peso de cada vértices da orla

typedef struct fringe {
  int tam;
  int *val;
} *Fringe;
  
Fringe newFringe (int N);
Fringe addV (Fringe f,int v, int c);
Fringe nextF (Fringe f,int *v);
Fringe updateV (Fringe f,int v, int c);



Fringe newFringe (int N){
  Fringe new = (Fringe) malloc(sizeof(struct fringe));
  int i;

  if (new==NULL) exit(-1);
  
  new->val = (int*) malloc(sizeof(int)*N);
  if (new->val==NULL) exit(-1);
  
  for (i=0; i<N; i++) new->val[i]=-1;
  new->tam=N;
  return new;
}


Fringe addV (Fringe f,int v, int c){
  f->val[v] = c;
  return f;
}

Fringe nextF (Fringe f,int *v){
  int i, m;
  
  for (i=0; i<f->tam && f->val[i]==-1; i++);
  if (i==f->tam) {printf("Orla vazia!"); return f;}
  m = i;
  for (; i<f->tam; i++)
    if (f->val[i]!=-1 && f->val[i]<f->val[m]) m=i;
  *v = m;  
  f->val[m] = -1;
  return f;
}

Fringe updateV (Fringe f,int v, int c){
  f->val[v] = c;
  return f;
}

