int crypto_hash(unsigned char out[32],
	      const unsigned char *in,
	      unsigned long long inlen);