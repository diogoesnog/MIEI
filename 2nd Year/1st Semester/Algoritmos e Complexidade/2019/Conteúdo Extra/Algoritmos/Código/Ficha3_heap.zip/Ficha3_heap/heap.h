#define PARENT(i) (i-1)/2 
#define LEFT(i) 2*i + 1
#define RIGHT(i) 2*i + 2

typedef int Elem;  

typedef struct {
 int   size;
 int   used;
 Elem  *values;
} Heap;

Heap *newHeap  (int size);
int minHeapOK (Heap h);
int  insertHeap(Heap *h, Elem x);
void bubbleUp  (Elem h[], int i);
int  extractMin(Heap *h, Elem *x);
void bubbleDown(Elem h[], int N);