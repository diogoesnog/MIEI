#include "heap.h"
#include <stdlib.h>

void swap(Elem *v, int a, int b) {
	Elem aux;
	aux = v[a];
	      v[a] = v[b];
	             v[b] = aux;
}

Heap *newHeap  (int size) {
	Heap *new = (Heap*)malloc(sizeof(Heap));
	new->size=size;
	new->used=0;
	new->values=(Elem*)malloc(size*sizeof(Elem));
	return new;
}

int minHeapOK (Heap h) {
	int i;
	for(i=1;i<h.used;i++) {
		if (h.values[i] < h.values[PARENT(i)])
			return 0;
	}
	return 1;
}

void bubbleUp  (Elem h[], int i) {
	while(i>0) {
		if (h[i] < h[PARENT(i)]) {
			swap(h,i,PARENT(i));
			i = PARENT(i);
		}
		else {
			break;
		}
	}
}

int  insertHeap(Heap *h, Elem x) {
	if (h->used == h-> size) 
		return 0;
	h->values[h->used] = x;
	bubbleUp(h->values,h->used);
	h->used++;
	return 1;
}

void bubbleDown(Elem h[], int N) {
	int toswap, current = 0;
	while (LEFT(current)<N) {
		// toswap vai ter o indice do elemento
		// que vai ficar na posicao current
		toswap = current;
		if (h[toswap] > h[LEFT(current)]) 
			toswap = LEFT(current);
		if ((RIGHT(current)<N) && (h[toswap] > h[RIGHT(current)]))
			toswap = RIGHT(current);
		if (toswap == current)
			break;
		swap(h,toswap,current);
		current = toswap;
	}
}

int  extractMin(Heap *h, Elem *x) {
	if (h->used == 0) 
		return 0;
	*x = h->values[0];
	h->used--;
	h->values[0] = h->values[h->used];
	bubbleDown(h->values,h->used);
	return 1;
}
