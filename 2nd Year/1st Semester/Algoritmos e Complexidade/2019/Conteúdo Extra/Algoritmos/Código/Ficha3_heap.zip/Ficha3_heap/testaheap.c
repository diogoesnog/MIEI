#include "heap.h"
#include <stdio.h>

int main(void) {
	int i;

	Heap *heap = newHeap(100);
	insertHeap(heap,4);
	insertHeap(heap,10);
	insertHeap(heap,21);
	insertHeap(heap,45);
	insertHeap(heap,13);
	insertHeap(heap,25);
	insertHeap(heap,22);
	insertHeap(heap,60);
	insertHeap(heap,100);
	insertHeap(heap,20);
	insertHeap(heap,6);
	while(extractMin(heap,&i)) {
		printf("%d\n",i);
	}
	return 0;
}