#include "queue.h"

typedef Queue Buffer;

Buffer initB (); 
int emptyB(Buffer b);
int addB(Buffer b, int v);
int nextB(Buffer b, int *v);
int removeB(Buffer b, int *v);
