#include "buffer.h"

Buffer initB () {
	return init();
} 

int emptyB(Buffer b) {
	return isEmpty(b);
}

int addB(Buffer b, int v) {
	return enqueue(b,v);
}

int nextB(Buffer b, int *v) {
	return front(b,v);
}

int removeB(Buffer b, int *v){
	return dequeue(b,v);
}
