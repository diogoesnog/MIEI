#define MaxQ 100

struct queue {
	int vals[MaxQ];
	int front;
	int back;
	int size;
};

typedef struct queue *Queue;

Queue init();
int enqueue(Queue q, int v);
int dequeue(Queue q, int *v);
int front(Queue q, int *v);
int isEmpty(Queue q);
