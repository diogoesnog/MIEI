#include "buffer.h"
#include <stdio.h>

int main(void) {
	int v;
	Buffer b = initB();
	addB(b,1);
	addB(b,2);
	addB(b,3);
	addB(b,4);
	addB(b,5);
	addB(b,6);
	addB(b,7);
	while (emptyB(b)==0) {
		removeB(b,&v);
		printf("Retirei %d\n",v);
	}
	return 0;
}