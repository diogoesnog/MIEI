#include "buffer.h"

Buffer initB () {
	return init();
} 

int emptyB(Buffer b) {
	return isEmpty(b);
}

int addB(Buffer b, int v) {
	return push(b,v);
}

int nextB(Buffer b, int *v) {
	return top(b,v);
}

int removeB(Buffer b, int *v){
	return pop(b,v);
}
