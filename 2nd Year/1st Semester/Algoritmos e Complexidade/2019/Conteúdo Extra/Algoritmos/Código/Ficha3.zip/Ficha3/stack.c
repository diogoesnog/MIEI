#include "stack.h"
#include <stdlib.h>

Stack init() {
	Stack s = (Stack)malloc(sizeof(struct stack));
	s->head = NULL;
	return s;
}

int push(Stack s, int v) {
	struct node *cabeca = s->head;
	struct node *novo = (struct node*)malloc(sizeof(struct node));
	if (!novo) return 0;
	novo->valor = v;
	novo->next = cabeca;
	s->head = novo;
	return 1;
}

int pop(Stack s, int *v) {
	struct node *cabeca = s->head;
	if (cabeca == NULL)
		return 0;
	*v = cabeca->valor;
	s->head = cabeca->next;
	free(cabeca);
	return 1;
}

int top(Stack s, int *v) {
	struct node *cabeca = s->head;
	if (cabeca == NULL)
		return 0;
	*v = cabeca->valor;
	return 1;
}

int isEmpty(Stack s) {
	if (s->head == NULL)
		return 1;
	return 0;
}
