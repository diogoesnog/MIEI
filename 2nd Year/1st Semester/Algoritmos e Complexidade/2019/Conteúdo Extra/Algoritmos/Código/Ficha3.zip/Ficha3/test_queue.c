#include "queue.h"
#include <stdio.h>

int main(void) {
	int v;
	Queue q = init();
	enqueue(q,1);
	enqueue(q,2);
	enqueue(q,3);
	enqueue(q,4);
	enqueue(q,5);
	enqueue(q,6);
	enqueue(q,7);
	while (isEmpty(q)==0) {
		dequeue(q,&v);
		printf("Retirei %d\n",v);
	}
	return 0;
}