#include "queue.h"
#include <stdlib.h>

Queue init() {
	Queue q = (Queue)malloc(sizeof(struct queue));
	q -> size = 0;
	q -> front = 0;
	q -> back = 0;
	return q;
}

int enqueue(Queue q, int v) {
	if (q->size == MaxQ)
		return 0;
	q->vals[q->back]=v;
	q->back++;
	if (q->back == MaxQ)
		q->back = 0;
	q->size++;
	return 1;
}

int dequeue(Queue q, int *v) {
	if (q->size == 0)
		return 0;
	*v = q->vals[q->front];
	q->front++;
	if (q->front == MaxQ)
		q->front = 0;
	q->size--;
	return 1;
	
}

int front(Queue q, int *v) {
	if (q->size == 0)
		return 0;
	*v = q->vals[q->front];
	return 1;	
}

int isEmpty(Queue q) {
	if (q->size == 0)
		return 1;
	return 0;	
}
