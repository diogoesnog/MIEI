#include "stack.h"
#include <stdio.h>

int main(void) {
	int v;
	Stack s = init();
	push(s,1);
	push(s,2);
	push(s,3);
	push(s,4);
	push(s,5);
	push(s,6);
	push(s,7);
	while (isEmpty(s)==0) {
		pop(s,&v);
		printf("Retirei %d\n",v);
	}
	return 0;
}