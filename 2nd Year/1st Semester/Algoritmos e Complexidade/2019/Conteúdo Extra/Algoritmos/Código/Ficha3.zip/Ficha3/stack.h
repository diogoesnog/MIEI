struct node {
	int valor;
	struct node *next;
};

struct stack {
	struct node *head;
};

typedef struct stack *Stack;

Stack init();
int push(Stack s, int v);
int pop(Stack s, int *v);
int top(Stack s, int *v);
int isEmpty(Stack s);
