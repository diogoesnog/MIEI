#include "graph_adjm.h"
#include "graph_adjv.h"
#include "graph_adjl.h"
#include <stdio.h>
#include <stdlib.h>

int main() {
	Graph_MA g_orig = create_GraphMA(6);
	addEdge_GraphMA(g_orig,0,1,2);
	addEdge_GraphMA(g_orig,0,2,1);
	addEdge_GraphMA(g_orig,1,2,3);
	addEdge_GraphMA(g_orig,1,5,5);
	addEdge_GraphMA(g_orig,2,3,1);
	addEdge_GraphMA(g_orig,3,1,4);
	addEdge_GraphMA(g_orig,4,1,3);
	addEdge_GraphMA(g_orig,4,3,1);
	addEdge_GraphMA(g_orig,4,5,2);
	print_GraphMA(g_orig);
	printf("----------------\n");
	Graph_LA g_la = convert_GraphMA_GraphLA(g_orig);
	print_GraphLA(g_la);
	printf("----------------\n");
	Graph_MA g_ma = convert_GraphLA_GraphMA(g_la);
	print_GraphMA(g_ma);
	printf("----------------\n");
	Graph_VA g_va = convert_GraphMA_GraphVA(g_orig);
	print_GraphVA(g_va);
	printf("----------------\n");
	g_ma = convert_GraphVA_GraphMA(g_va);
	print_GraphMA(g_ma);
	printf("----------------\n");
	g_la = convert_GraphVA_GraphLA(g_va);
	print_GraphLA(g_la);
	printf("----------------\n");
	g_va = convert_GraphLA_GraphVA(g_la);
	print_GraphVA(g_va);
	printf("----------------\n");
	return 0;
}