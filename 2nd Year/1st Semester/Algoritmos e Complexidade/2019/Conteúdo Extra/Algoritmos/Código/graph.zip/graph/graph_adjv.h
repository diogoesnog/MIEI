#ifndef GRAPH_ADJV
#define GRAPH_ADJV

#define MAX_VERTEX 10

typedef struct graph_VA {
	int V;
	int *adj_vec;
	int *wei_vec;
	int *adj_idx;
} Graph_VA;

Graph_VA create_GraphVA(int V);
void addEdge_GraphVA(Graph_VA g, int s, int d, int w);
void print_GraphVA(Graph_VA g);

#include "graph_adjm.h"
#include "graph_adjl.h"

Graph_VA convert_GraphLA_GraphVA(Graph_LA g);
Graph_VA convert_GraphMA_GraphVA(Graph_MA g);

#endif
