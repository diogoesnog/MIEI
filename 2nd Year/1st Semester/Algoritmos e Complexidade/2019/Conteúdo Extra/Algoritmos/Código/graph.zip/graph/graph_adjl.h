#ifndef GRAPH_ADJL
#define GRAPH_ADJL

#define MAX_VERTEX 10

typedef struct edge {
	int weight;
	int dest;
	struct edge *next;
} Edge;

typedef struct graph_LA {
	Edge **adj_ls;
	int V;
} Graph_LA;

Graph_LA create_GraphLA(int V);
void addEdge_GraphLA(Graph_LA g, int s, int d, int w);
void print_GraphLA(Graph_LA g);

#include "graph_adjm.h"
#include "graph_adjv.h"

Graph_LA convert_GraphMA_GraphLA(Graph_MA g);
Graph_LA convert_GraphVA_GraphLA(Graph_VA g);

#endif
