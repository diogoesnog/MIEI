#ifndef GRAPH_ADJM
#define GRAPH_ADJM

#define MAX_VERTEX 10

typedef struct graph_MA {
	int V;
	int *adj_tab;
} Graph_MA;

Graph_MA create_GraphMA(int V);
void addEdge_GraphMA(Graph_MA g, int s, int d, int w);
void print_GraphMA(Graph_MA g);

#include "graph_adjl.h"
#include "graph_adjv.h"

Graph_MA convert_GraphLA_GraphMA(Graph_LA g);
Graph_MA convert_GraphVA_GraphMA(Graph_VA g);

#endif
